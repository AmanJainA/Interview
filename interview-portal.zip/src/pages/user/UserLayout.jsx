import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

export default function UserLayout() {
  const { profile, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate('/login');
  }

  return (
    <div className="d-flex">
      <div className="sidebar" style={{ width: 240 }}>
        <div className="p-3 border-bottom border-secondary">
          <div className="fw-bold text-white">{profile?.name}</div>
          <small>{profile?.email}</small>
        </div>
        <NavLink to="/dashboard" end className={({ isActive }) => (isActive ? 'active' : '')}>
          Dashboard
        </NavLink>
        <NavLink to="/dashboard/assessment" className={({ isActive }) => (isActive ? 'active' : '')}>
          Assessment
        </NavLink>
        <a href="#" onClick={handleLogout}>
          Logout
        </a>
      </div>
      <div className="flex-grow-1 p-4">
        <Outlet />
      </div>
    </div>
  );
}

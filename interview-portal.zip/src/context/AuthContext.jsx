import { createContext, useContext, useEffect, useState } from 'react';
import { supabase, db } from '../supabaseClient';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null); // row from interview.users
  const [loading, setLoading] = useState(true);

  async function loadProfile(userId) {
    const { data, error } = await db('users').select('*').eq('id', userId).single();
    if (!error) setProfile(data);
    return data;
  }

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      setSession(session);
      if (session) await loadProfile(session.user.id);
      setLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setSession(session);
      if (session) {
        await loadProfile(session.user.id);
      } else {
        setProfile(null);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  async function register({ name, email, password, stream, location }) {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) throw error;
    // If email confirmation is off, data.user is already signed in.
    if (data.user) {
      const { error: profileError } = await db('users').insert({
        id: data.user.id,
        name,
        email,
        stream,
        location,
        usertype: 'user',
      });
      if (profileError) throw profileError;
    }
    return data;
  }

  async function login({ email, password }) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    const p = await loadProfile(data.user.id);
    return p;
  }

  async function logout() {
    await supabase.auth.signOut();
  }

  const value = { session, profile, loading, register, login, logout, refreshProfile: () => session && loadProfile(session.user.id) };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}

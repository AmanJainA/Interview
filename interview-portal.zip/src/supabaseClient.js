import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Every table lives under the "interview" schema, so every
// query goes through this helper instead of supabase.from(...)
export const db = (table) => supabase.schema('interview').from(table);

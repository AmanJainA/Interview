import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

import UserLayout from './pages/user/UserLayout.jsx';
import Home from './pages/user/Home.jsx';
import Assessment from './pages/user/Assessment.jsx';
import ThankYou from './pages/user/ThankYou.jsx';

import AdminLayout from './pages/admin/AdminLayout.jsx';
import AdminDashboard from './pages/admin/AdminDashboard.jsx';
import AdminResults from './pages/admin/AdminResults.jsx';
import AdminContent from './pages/admin/AdminContent.jsx';
import AdminTracking from './pages/admin/AdminTracking.jsx';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* USER */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute role="user">
            <UserLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Home />} />
        <Route path="assessment" element={<Assessment />} />
        <Route path="thank-you" element={<ThankYou />} />
      </Route>

      {/* ADMIN */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute role="admin">
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<AdminDashboard />} />
        <Route path="results" element={<AdminResults />} />
        <Route path="tracking" element={<AdminTracking />} />
        <Route path="about" element={<AdminContent section="about" />} />
        <Route path="instructions" element={<AdminContent section="instructions" />} />
        <Route path="questions" element={<AdminContent section="questions" />} />
        <Route path="settings" element={<AdminContent section="settings" />} />
      </Route>

      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
